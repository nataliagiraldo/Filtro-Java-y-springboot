package com.proyecto1;
import java.util.Arrays;
import java.util.Scanner;
import com.crativecode.Arrays.models.Persona;
public class Main {
    public static void main(String[] args) {

        System.out.println("ingrese su nombre: ");
        Arrays<String> nombres = new Arrays<>():
        system.

    }
}

